sum=0
#strt=int(input("Enter the Starting Number:- "))
#finsh=int(input("ENter the Last Number:- "))
for i in range(0,5):
	sum=sum+i
print("Addition is:- ",sum)
