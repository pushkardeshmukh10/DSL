age= int(input("Enter Your age:- "))
if age>=18:
  print("You are Eligible to vote")
else:
  print("Sorrry! You're not eligible For Vote")
