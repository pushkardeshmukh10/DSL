dictionary = {
    "Name" : "Om Deore",
    "Roll_No" :31,
    "Branch" : "Computer Engineering"
    }
print("Student Name:- ", dictionary["Name"])
print("Student Roll Number:-",dictionary["Roll_No"])
print("Student Branch:- ",dictionary["Branch"])
dictionary["Name"]="COMPUTER ENGG."
print("Student Name:- ", dictionary["Name"])
